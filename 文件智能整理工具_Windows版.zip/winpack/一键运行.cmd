@echo off
chcp 65001 >nul
title 文件智能整理工具
echo ========================================
echo    📂 文件智能整理工具 v1.0
echo    正在检测 Python 环境...
echo ========================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ 未检测到 Python！
    echo 请先安装 Python 3.8+，下载地址：
    echo https://www.python.org/downloads/
    echo.
    echo 安装时请勾选 "Add Python to PATH"
    pause
    exit /b
)

echo ✅ Python 已安装
echo.
echo 正在启动工具...
python file_organizer.py
if %errorlevel% neq 0 (
    echo.
    echo ❌ 启动失败，可能是缺少 tkinter 组件
    echo 请重新安装 Python，安装时勾选 "tcl/tk and IDLE"
    pause
)
pause

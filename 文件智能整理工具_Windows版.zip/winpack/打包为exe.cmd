@echo off
chcp 65001 >nul
title 打包文件智能整理工具
echo ========================================
echo    📦 正在打包为 exe...
echo ========================================
echo.

python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ❌ 未检测到 Python，请先安装
    pause
    exit /b
)

echo 正在安装 PyInstaller...
pip install pyinstaller

echo.
echo 正在打包为单文件 exe...
pyinstaller --onefile --noconsole --name "文件智能整理工具" file_organizer.py

echo.
echo ✅ 打包完成！
echo exe 文件在 dist 文件夹中
pause
